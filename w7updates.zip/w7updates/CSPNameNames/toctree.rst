8. Ünite ~ İşlev ve Yordamların İsimlendirilip Çağrılması
:::::::::::::::::::::::::::::::::::::::

.. toctree::
   :maxdepth: 2

   names4names2.rst
   nameFandP.rst
   nameSteps.rst
   namesInput.rst
   nameSets.rst
   renameFunctions.rst
   ch6_summary.rst
   ch6_exercises.rst
