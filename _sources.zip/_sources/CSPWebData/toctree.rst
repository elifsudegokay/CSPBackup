Chapter 18 - Working with Data on the Web
::::::::::::::::::::::::::::::::::::::::::::

.. toctree::
   :maxdepth: 2

   webData.rst
   pollData.rst
   readData.rst
   largestPoll.rst
   lowestPoll.rst
   avgPoll.rst
   datastates.rst
   findPollState.rst
   ch18_summary.rst
   ch18_exercises.rst