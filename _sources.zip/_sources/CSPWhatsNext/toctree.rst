Chapter 23 - What's Next?
::::::::::::::::::::::::::::::::::::::::::::

.. toctree::
   :maxdepth: 2

   whatsNext.rst