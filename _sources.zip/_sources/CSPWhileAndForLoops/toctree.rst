6. Ünite ~ while ve for Döngüleri
:::::::::::::::::::::::::::::::::::::::::

.. toctree::
   :maxdepth: 2

   forAndWhile.rst
   infinite.rst
   whileCount.rst
   while.rst
   nestedLoops.rst
   ch8_summary.rst
   ch8_exercises.rst
   exam7a8.rst
