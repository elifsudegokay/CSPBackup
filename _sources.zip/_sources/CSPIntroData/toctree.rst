Chapter 16 - Working with Collections
::::::::::::::::::::::::::::::::::::::

.. toctree::
   :maxdepth: 2

   workColls.rst
   workStrings.rst
   workLists.rst
   listIndexes.rst
   revList.rst
   rangeChange.rst
   decRange.rst
   forEach.rst
   rainfall.rst
   ch16_summary.rst
   ch16_exercises.rst