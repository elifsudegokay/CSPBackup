Chapter 22 - Global Impact
::::::::::::::::::::::::::::::::::::::::::::

.. toctree::
   :maxdepth: 2

   intro.rst
   exploring.rst
   task.rst
   deciding.rst
   choosing.rst
   outline.rst
   completing.rst
   working.rst