..  Copyright (C)  Mark Guzdial, Barbara Ericson, Briana Morrison
    Permission is granted to copy, distribute and/or modify this document
    under the terms of the GNU Free Documentation License, Version 1.3 or
    any later version published by the Free Software Foundation; with
    Invariant Sections being Forward, Prefaces, and Contributor List,
    no Front-Cover Texts, and no Back-Cover Texts.  A copy of the license
    is included in the section entitled "GNU Free Documentation License".


Project Examples
====================

.. index:: Creativity


Here are some resources to jumpstart your own programming ideas:
	| - “Homework” section on the `University of Pennsylvania CS101 website <https://sites.google.com/site/penncis101/2012-spring/homework>`_ 
	| - “Assignments” page on the `University of Alabama CS104 website <http://cs104.cs.ua.edu/index_files/Assignments.htm>`_ 
	| - “BJC Related Projects” on the `University of California, Berkeley Beauty and Joy of Computing website <http://bjc.berkeley.edu/website/curriculum.html>`_  
