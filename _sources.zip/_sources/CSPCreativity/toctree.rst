Chapter 21 - Creativity
::::::::::::::::::::::::::::::::::::::::::::

.. toctree::
    :maxdepth: 2

    intro.rst
    task.rst
    deciding.rst
    examples.rst
    processQ.rst
    programming.rst
    referencing.rst