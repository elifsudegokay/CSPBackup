Chapter 15 - Using Decisions with Images
::::::::::::::::::::::::::::::::::::::::::::

.. toctree::
   :maxdepth: 2

   decImages.rst
   combineImages.rst
   imageIfElse.rst
   imageMultIf.rst
   ch15_summary.rst
   ch15_exercises.rst
   exam14a15.rst