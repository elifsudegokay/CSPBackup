5. Ünite ~ Bilgisayarlar Adımları Tekrar Edebilir
:::::::::::::::::::::::::::::::::::::::::

.. toctree::
   :maxdepth: 2

   repeatSteps.rst
   repeatNums.rst
   list.rst
   range.rst
   accumPattern.rst
   print.rst
   ch7_summary.rst
   ch7_exercises.rst
